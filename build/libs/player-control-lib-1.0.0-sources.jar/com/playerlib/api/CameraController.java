package com.playerlib.api;

import net.minecraft.class_310;

public class CameraController {
    private static final class_310 client = class_310.method_1551();
    
    public static void up(float degrees) {
        if (client.field_1724 == null) return;
        float currentPitch = client.field_1724.method_36455();
        float newPitch = Math.max(-90, Math.min(90, currentPitch - degrees));
        setPitch(newPitch);
    }
    
    public static void down(float degrees) {
        if (client.field_1724 == null) return;
        float currentPitch = client.field_1724.method_36455();
        float newPitch = Math.max(-90, Math.min(90, currentPitch + degrees));
        setPitch(newPitch);
    }
    
    public static void right(float degrees) {
        if (client.field_1724 == null) return;
        float currentYaw = client.field_1724.method_36454();
        float newYaw = (currentYaw + degrees) % 360;
        setYaw(newYaw);
    }
    
    public static void left(float degrees) {
        if (client.field_1724 == null) return;
        float currentYaw = client.field_1724.method_36454();
        float newYaw = (currentYaw - degrees) % 360;
        setYaw(newYaw);
    }
    
    public static void setPitch(float pitch) {
        if (client.field_1724 == null) return;
        pitch = Math.max(-90, Math.min(90, pitch));
        client.field_1724.method_36457(pitch);
    }
    
    public static void setYaw(float yaw) {
        if (client.field_1724 == null) return;
        client.field_1724.method_36456(yaw);
    }
    
    public static float getPitch() {
        return client.field_1724 != null ? client.field_1724.method_36455() : 0;
    }
    
    public static float getYaw() {
        return client.field_1724 != null ? client.field_1724.method_36454() : 0;
    }
    
    public static float[] getLookVector() {
        if (client.field_1724 == null) return new float[]{0, 0, 0};
        return new float[]{
            client.field_1724.method_36454(),
            client.field_1724.method_36455(),
            0
        };
    }
}