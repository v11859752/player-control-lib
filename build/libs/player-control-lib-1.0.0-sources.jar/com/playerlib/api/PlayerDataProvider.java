package com.playerlib.api;

import com.playerlib.data.PlayerData;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class PlayerDataProvider {
    private static final Map<String, Consumer<PlayerData>> listeners = new HashMap<>();
    private static PlayerData lastData = null;
    
    public static void subscribe(String modId, Consumer<PlayerData> callback) {
        listeners.put(modId, callback);
        if (lastData != null) {
            callback.accept(lastData);
        }
    }
    
    public static void unsubscribe(String modId) {
        listeners.remove(modId);
    }
    
    public static void updateData() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        
        class_1657 p = client.field_1724;
        
        List<String> inventory = p.method_31548().field_7547.stream()
                .filter(stack -> !stack.method_7960())
                .map(stack -> stack.method_7909().method_7876())
                .collect(Collectors.toList());
        
        lastData = new PlayerData(
            p.method_23317(),
            p.method_23318(),
            p.method_23321(),
            p.method_36454(),
            p.method_36455(),
            p.method_6032(),
            p.method_7344().method_7586(),
            p.method_7344().method_7589(),
            p.field_7520,
            p.method_31548().field_7545,
            inventory
        );
        
        listeners.values().forEach(callback -> callback.accept(lastData));
    }
    
    public static PlayerData getLastData() {
        return lastData;
    }
}